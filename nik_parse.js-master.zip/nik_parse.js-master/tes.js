/*******************************************
 * #### nik_parse.js ####
 * Parse Nomor Induk Kependudukan (NIK) KTP
 * Coded by @bachors 2018.
 * https://github.com/bachors/nik_parse.js
 * Updates will be posted to this site.
 *******************************************/

 const NIK = require('./src/nik_parse');

 const result = NIK('0276234927452347')
 console.log(result);